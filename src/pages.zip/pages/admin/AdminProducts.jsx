import React, { useEffect, useMemo, useState } from 'react';
import { Edit, GripVertical, ImagePlus, Trash2, Upload } from 'lucide-react';
import { api } from '../../api';
import { formatDate, Modal, PageHeader, Pagination } from './AdminHelpers';

const emptyProduct = {
  name: '',
  composition: '',
  formulation: '',
  status: '',
  description: '',
  packing_size: '',
  division: '',
  product_category: '',
};

export default function AdminProducts() {
  const [rows, setRows] = useState([]);
  const [divisions, setDivisions] = useState([]);
  const [categories, setCategories] = useState([]);
  const [meta, setMeta] = useState({});
  const [page, setPage] = useState(1);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyProduct);
  const [images, setImages] = useState([]);
  const [draggingImageId, setDraggingImageId] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [search, setSearch] = useState('');
  const [error, setError] = useState('');

  const params = useMemo(() => ({ page, page_size: 10, search }), [page, search]);

  const load = () => api.adminProducts(params).then((data) => {
    setRows(data.results);
    setMeta(data);
  });

  useEffect(() => {
    Promise.all([
      api.adminDivisions({ page_size: 100 }),
      api.adminCategories({ page_size: 100 }),
    ]).then(([divisionData, categoryData]) => {
      setDivisions(divisionData.results);
      setCategories(categoryData.results);
    });
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      load().catch((err) => setError(err.message));
    }, 250);
    return () => clearTimeout(timer);
  }, [params]);

  const openForm = (row = null) => {
    setEditing(row || {});
    setImages(row?.images || []);
    setForm(row ? {
      name: row.name || '',
      composition: row.composition || '',
      formulation: row.formulation || '',
      status: row.status || '',
      description: row.description || '',
      packing_size: row.packing_size || '',
      division: row.division || '',
      product_category: row.product_category || '',
    } : emptyProduct);
    setError('');
  };

  const updateField = (field, value) => {
    setForm((current) => ({ ...current, [field]: value }));
  };

  const save = async (event) => {
    event.preventDefault();
    try {
      if (editing.id) {
        const updated = await api.updateProduct(editing.id, form);
        setEditing(updated);
        setImages(updated.images || []);
      } else {
        const created = await api.createProduct(form);
        setEditing(created);
        setImages(created.images || []);
      }
      await load();
    } catch (err) {
      setError(err.message);
    }
  };

  const uploadImages = async (event) => {
    const files = event.target.files;
    if (!editing?.id || !files?.length) return;
    setUploading(true);
    try {
      const data = await api.uploadProductImages(editing.id, files);
      setImages((current) => [...current, ...data.results]);
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setUploading(false);
      event.target.value = '';
    }
  };

  const deleteImage = async (image) => {
    if (!window.confirm(`Delete image "${image.file_name}"?`)) return;
    await api.deleteProductImage(image.id);
    setImages((current) => current.filter((item) => item.id !== image.id).map((item, index) => ({ ...item, order_no: index + 1 })));
    await load();
  };

  const moveImage = async (targetImageId) => {
    if (!draggingImageId || draggingImageId === targetImageId) return;
    const fromIndex = images.findIndex((image) => image.id === draggingImageId);
    const toIndex = images.findIndex((image) => image.id === targetImageId);
    if (fromIndex < 0 || toIndex < 0) return;

    const next = [...images];
    const [moved] = next.splice(fromIndex, 1);
    next.splice(toIndex, 0, moved);
    const normalized = next.map((image, index) => ({ ...image, order_no: index + 1 }));
    setImages(normalized);
    setDraggingImageId(null);

    try {
      const data = await api.reorderProductImages(editing.id, normalized.map((image) => image.id));
      setImages(data.results);
      await load();
    } catch (err) {
      setError(err.message);
    }
  };

  const remove = async (row) => {
    if (!window.confirm(`Delete product "${row.name}"?`)) return;
    await api.deleteProduct(row.id);
    await load();
  };

  return (
    <div>
      <PageHeader title="Products" subtitle="Create and manage backend product records." onAdd={() => openForm()} addLabel="Add Product" />
      <div className="mt-6 flex flex-col gap-3 sm:flex-row">
        <input
          value={search}
          onChange={(event) => {
            setSearch(event.target.value);
            setPage(1);
          }}
          placeholder="Search products..."
          className="w-full rounded-lg border border-slate-200 bg-white px-4 py-3 sm:max-w-md"
        />
      </div>
      {error && <div className="mt-6 rounded-lg border border-red-200 bg-red-50 p-4 text-red-700">{error}</div>}
      <div className="mt-8 overflow-x-auto rounded-lg border border-slate-200 bg-white shadow-sm">
        <table className="w-full min-w-[980px] text-left">
          <thead className="bg-slate-50 text-xs uppercase tracking-wider text-slate-500">
            <tr>
              <th className="px-5 py-4">Name</th>
              <th className="px-5 py-4">Division</th>
              <th className="px-5 py-4">Category</th>
              <th className="px-5 py-4">Status</th>
              <th className="px-5 py-4">Created</th>
              <th className="px-5 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map((row) => (
              <tr key={row.id}>
                <td className="px-5 py-4 font-bold text-slate-900">{row.name}</td>
                <td className="px-5 py-4 text-sm text-slate-600">{row.division_name}</td>
                <td className="px-5 py-4 text-sm text-slate-600">{row.product_category_name}</td>
                <td className="px-5 py-4 text-sm text-slate-600">{row.status || '-'}</td>
                <td className="px-5 py-4 text-sm text-slate-500">{formatDate(row.created_at)}</td>
                <td className="px-5 py-4">
                  <div className="flex justify-end gap-2">
                    <button onClick={() => openForm(row)} className="grid h-9 w-9 place-items-center rounded-lg bg-slate-100 text-slate-600"><Edit size={16} /></button>
                    <button onClick={() => remove(row)} className="grid h-9 w-9 place-items-center rounded-lg bg-red-50 text-red-600"><Trash2 size={16} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Pagination meta={meta} onPage={setPage} />

      {editing && (
        <Modal title={editing.id ? 'Edit Product' : 'Add Product'} onClose={() => setEditing(null)}>
          <form onSubmit={save} className="grid gap-5">
            <div className="grid gap-4 sm:grid-cols-2">
              <label className="grid gap-2 text-sm font-bold text-slate-600">
                Name
                <input value={form.name} onChange={(event) => updateField('name', event.target.value)} className="rounded-lg border border-slate-200 px-4 py-3 font-normal text-slate-900" />
              </label>
              <label className="grid gap-2 text-sm font-bold text-slate-600">
                Formulation
                <input value={form.formulation} onChange={(event) => updateField('formulation', event.target.value)} className="rounded-lg border border-slate-200 px-4 py-3 font-normal text-slate-900" />
              </label>
              <label className="grid gap-2 text-sm font-bold text-slate-600">
                Status
                <input value={form.status} onChange={(event) => updateField('status', event.target.value)} placeholder="Prescription drugs only" className="rounded-lg border border-slate-200 px-4 py-3 font-normal text-slate-900" />
              </label>
              <label className="grid gap-2 text-sm font-bold text-slate-600">
                Packing Size
                <input value={form.packing_size} onChange={(event) => updateField('packing_size', event.target.value)} placeholder="50*2*10 Blister pack" className="rounded-lg border border-slate-200 px-4 py-3 font-normal text-slate-900" />
              </label>
              <label className="grid gap-2 text-sm font-bold text-slate-600">
                Division
                <select value={form.division} onChange={(event) => updateField('division', event.target.value)} className="rounded-lg border border-slate-200 px-4 py-3 font-normal text-slate-900">
                  <option value="">Select division</option>
                  {divisions.map((division) => <option key={division.id} value={division.id}>{division.name}</option>)}
                </select>
              </label>
              <label className="grid gap-2 text-sm font-bold text-slate-600">
                Product Category
                <select value={form.product_category} onChange={(event) => updateField('product_category', event.target.value)} className="rounded-lg border border-slate-200 px-4 py-3 font-normal text-slate-900">
                  <option value="">Select category</option>
                  {categories.map((category) => <option key={category.id} value={category.id}>{category.name}</option>)}
                </select>
              </label>
            </div>
            <label className="grid gap-2 text-sm font-bold text-slate-600">
              Composition
              <textarea rows={4} value={form.composition} onChange={(event) => updateField('composition', event.target.value)} className="rounded-lg border border-slate-200 px-4 py-3 font-normal text-slate-900" />
            </label>
            <label className="grid gap-2 text-sm font-bold text-slate-600">
              Description
              <textarea rows={7} value={form.description} onChange={(event) => updateField('description', event.target.value)} className="rounded-lg border border-slate-200 px-4 py-3 font-normal text-slate-900" />
            </label>
            <div className="rounded-lg border border-slate-200 bg-slate-50 p-4">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="text-sm font-black text-slate-900">Product Images</p>
                  <p className="mt-1 text-sm text-slate-500">
                    Save the product first, then upload images. Drag thumbnails to change display order.
                  </p>
                </div>
                <label className={`inline-flex items-center justify-center gap-2 rounded-lg px-4 py-3 text-sm font-black text-white ${editing.id ? 'cursor-pointer bg-teal' : 'cursor-not-allowed bg-slate-300'}`}>
                  <Upload size={17} />
                  {uploading ? 'Uploading...' : 'Upload Images'}
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    disabled={!editing.id || uploading}
                    onChange={uploadImages}
                    className="hidden"
                  />
                </label>
              </div>

              <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {images.map((image) => (
                  <div
                    key={image.id}
                    draggable
                    onDragStart={() => setDraggingImageId(image.id)}
                    onDragOver={(event) => event.preventDefault()}
                    onDrop={() => moveImage(image.id)}
                    className="overflow-hidden rounded-lg border border-slate-200 bg-white"
                  >
                    <div className="relative aspect-video bg-slate-100">
                      <img src={image.url} alt={image.file_name} className="h-full w-full object-cover" />
                      <span className="absolute left-2 top-2 rounded-full bg-slate-950/75 px-2 py-1 text-xs font-black text-white">
                        {image.order_no}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 p-3">
                      <GripVertical size={16} className="shrink-0 text-slate-400" />
                      <span className="min-w-0 flex-1 truncate text-xs font-bold text-slate-600">{image.file_name}</span>
                      <button type="button" onClick={() => deleteImage(image)} className="grid h-8 w-8 place-items-center rounded-lg bg-red-50 text-red-600">
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </div>
                ))}
                {!images.length && (
                  <div className="grid min-h-40 place-items-center rounded-lg border border-dashed border-slate-300 bg-white p-6 text-center text-slate-400 sm:col-span-2 lg:col-span-3">
                    <div>
                      <ImagePlus className="mx-auto mb-2" />
                      <p className="text-sm font-bold">No images uploaded</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
            <div className="flex gap-3">
              <button className="w-fit rounded-lg bg-teal px-5 py-3 text-sm font-black text-white">Save Product</button>
              {editing.id && (
                <button type="button" onClick={() => setEditing(null)} className="w-fit rounded-lg border border-slate-200 px-5 py-3 text-sm font-black text-slate-600">
                  Close
                </button>
              )}
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
