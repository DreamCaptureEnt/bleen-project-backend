import React, { useEffect, useState } from 'react';
import { ArrowLeft, CalendarDays, Package, Pill } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { api } from '../api';

function formatDate(value) {
  if (!value) return '';
  return new Intl.DateTimeFormat('en-IN', {
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(new Date(value));
}

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    api.product(id)
      .then((data) => {
        setProduct(data);
        setError('');
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) {
    return <div className="min-h-screen bg-slate-50 px-4 py-24 text-center text-slate-500">Loading product...</div>;
  }

  if (error || !product) {
    return (
      <div className="min-h-screen bg-slate-50 px-4 py-24 text-center">
        <p className="text-lg text-slate-600">{error || 'Product not found.'}</p>
        <button onClick={() => navigate('/products')} className="mt-6 rounded-full bg-teal px-6 py-3 text-sm font-bold text-white">
          Back to Products
        </button>
      </div>
    );
  }

  const images = product.images || [];
  const [firstImage, ...otherImages] = images;

  return (
    <div className="min-h-screen bg-slate-50">
      <nav className="border-b border-slate-200 bg-white px-4 py-4 sm:px-6">
        <div className="mx-auto flex max-w-6xl items-center gap-4">
          <button onClick={() => navigate('/products')} className="inline-flex items-center gap-2 text-sm font-bold text-teal">
            <ArrowLeft size={18} />
            Products
          </button>
          <span className="text-sm text-slate-400">/</span>
          <span className="truncate text-sm font-semibold text-slate-600">{product.name}</span>
        </div>
      </nav>

      <header className="bg-gradient-to-br from-teal to-navy px-4 py-16 text-white sm:px-6">
        <div className="mx-auto max-w-6xl">
          <div className="flex flex-wrap gap-3">
            <span className="rounded-full bg-white/20 px-4 py-2 text-xs font-bold uppercase tracking-widest">{product.division_name}</span>
            <span className="rounded-full bg-white/20 px-4 py-2 text-xs font-bold uppercase tracking-widest">{product.product_category_name}</span>
          </div>
          <h1 className="mt-6 max-w-4xl text-4xl font-black leading-tight sm:text-6xl">{product.name}</h1>
          {product.status && <p className="mt-5 text-lg font-semibold text-white/85">{product.status}</p>}
        </div>
      </header>

      <main className="mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:px-6 lg:grid-cols-[0.85fr_1.15fr]">
        <aside className="h-fit rounded-lg border border-slate-200 bg-white p-6 shadow-sm">
          <div className="grid aspect-square place-items-center overflow-hidden rounded-lg bg-gradient-to-br from-teal-50 to-blue-50">
            {firstImage ? (
              <img src={firstImage.url} alt={product.name} className="h-full w-full object-contain" />
            ) : (
              <div className="grid h-36 w-36 place-items-center rounded-full bg-white text-4xl font-black text-teal shadow-inner">
                {product.name.slice(0, 2).toUpperCase()}
              </div>
            )}
          </div>
          {otherImages.length > 0 && (
            <div className="mt-4 grid grid-cols-4 gap-2">
              {otherImages.map((image) => (
                <div key={image.id} className="aspect-square overflow-hidden rounded-lg border border-slate-200 bg-slate-50">
                  <img src={image.url} alt={image.file_name} className="h-full w-full object-cover" />
                </div>
              ))}
            </div>
          )}
          <div className="mt-6 space-y-3 text-sm">
            <div className="flex items-center gap-3 rounded-lg bg-slate-50 p-3">
              <Pill size={18} className="text-teal" />
              <span className="font-semibold text-slate-700">{product.formulation || 'Formulation not specified'}</span>
            </div>
            <div className="flex items-center gap-3 rounded-lg bg-slate-50 p-3">
              <Package size={18} className="text-teal" />
              <span className="font-semibold text-slate-700">{product.packing_size || 'Packing size not specified'}</span>
            </div>
            <div className="flex items-center gap-3 rounded-lg bg-slate-50 p-3">
              <CalendarDays size={18} className="text-teal" />
              <span className="font-semibold text-slate-700">{formatDate(product.created_at)}</span>
            </div>
          </div>
        </aside>

        <section className="rounded-lg border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
          <div className="grid gap-6">
            <div>
              <p className="text-xs font-black uppercase tracking-[0.18em] text-teal">Composition</p>
              <p className="mt-3 whitespace-pre-line leading-8 text-slate-700">{product.composition || 'Not specified'}</p>
            </div>
            <div className="h-px bg-slate-100" />
            <div>
              <p className="text-xs font-black uppercase tracking-[0.18em] text-teal">Description</p>
              <p className="mt-3 whitespace-pre-line leading-8 text-slate-700">{product.description || 'No description added.'}</p>
            </div>
            <div className="h-px bg-slate-100" />
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="rounded-lg bg-slate-50 p-4">
                <p className="text-xs font-black uppercase tracking-wider text-slate-400">Formulation</p>
                <p className="mt-2 font-bold text-slate-900">{product.formulation || '-'}</p>
              </div>
              <div className="rounded-lg bg-slate-50 p-4">
                <p className="text-xs font-black uppercase tracking-wider text-slate-400">Status</p>
                <p className="mt-2 font-bold text-slate-900">{product.status || '-'}</p>
              </div>
              <div className="rounded-lg bg-slate-50 p-4">
                <p className="text-xs font-black uppercase tracking-wider text-slate-400">Division</p>
                <p className="mt-2 font-bold text-slate-900">{product.division_name}</p>
              </div>
              <div className="rounded-lg bg-slate-50 p-4">
                <p className="text-xs font-black uppercase tracking-wider text-slate-400">Product Category</p>
                <p className="mt-2 font-bold text-slate-900">{product.product_category_name}</p>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
