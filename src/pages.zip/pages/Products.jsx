import React, { useEffect, useMemo, useState } from 'react';
import { Search, X } from 'lucide-react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { api } from '../api';

function ProductCard({ product, onClick }) {
  const firstImage = product.images?.[0];

  return (
    <article
      onClick={onClick}
      className="group cursor-pointer overflow-hidden rounded-lg border border-slate-100 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-xl"
    >
      <div className="grid aspect-square place-items-center bg-gradient-to-br from-teal-50 to-blue-50">
        {firstImage ? (
          <img src={firstImage.url} alt={product.name} className="h-full w-full object-cover transition duration-300 group-hover:scale-105" />
        ) : (
          <div className="grid h-28 w-28 place-items-center rounded-full bg-white text-3xl font-bold text-teal shadow-inner">
            {product.name.slice(0, 2).toUpperCase()}
          </div>
        )}
      </div>
      <div className="p-5">
        <p className="text-xs font-bold uppercase tracking-wider text-teal">{product.product_category_name}</p>
        <h3 className="mt-2 text-lg font-bold leading-snug text-slate-900">{product.name}</h3>
        <p className="mt-2 text-sm text-slate-500">{product.division_name}</p>
      </div>
    </article>
  );
}

export default function Products() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [products, setProducts] = useState([]);
  const [divisions, setDivisions] = useState([]);
  const [categories, setCategories] = useState([]);
  const [search, setSearch] = useState('');
  const [division, setDivision] = useState('');
  const [category, setCategory] = useState('');
  const [page, setPage] = useState(1);
  const [meta, setMeta] = useState({ count: 0, total_pages: 1 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const divisionParam = searchParams.get('division');
    if (divisionParam) setDivision(divisionParam);
  }, [searchParams]);

  useEffect(() => {
    Promise.all([
      api.divisions({ page_size: 100 }),
      api.categories({ page_size: 100 }),
    ])
      .then(([divisionData, categoryData]) => {
        setDivisions(divisionData.results);
        setCategories(categoryData.results);
      })
      .catch((err) => setError(err.message));
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(true);
      api.products({ page, page_size: 12, search, division, category })
        .then((data) => {
          setProducts(data.results);
          setMeta(data);
          setError('');
        })
        .catch((err) => setError(err.message))
        .finally(() => setLoading(false));
    }, 250);
    return () => clearTimeout(timer);
  }, [page, search, division, category]);

  const hasFilters = useMemo(() => search || division || category, [search, division, category]);

  const resetFilters = () => {
    setSearch('');
    setDivision('');
    setCategory('');
    setPage(1);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <section className="bg-gradient-to-br from-teal to-navy px-4 py-20 text-white sm:px-6">
        <div className="mx-auto max-w-5xl text-center">
          <p className="text-sm font-bold uppercase tracking-[0.22em] text-white/75">Product Catalogue</p>
          <h1 className="mt-5 text-4xl font-black leading-tight sm:text-6xl">Trusted Formulations</h1>
          <p className="mx-auto mt-5 max-w-2xl text-base leading-7 text-white/85">
            Browse Bleen products dynamically from the backend by division, product category, or search.
          </p>
          <div className="relative mx-auto mt-9 max-w-xl">
            <Search className="absolute left-5 top-1/2 h-5 w-5 -translate-y-1/2 text-teal" />
            <input
              value={search}
              onChange={(event) => {
                setSearch(event.target.value);
                setPage(1);
              }}
              placeholder="Search product, composition, category..."
              className="w-full rounded-full border-0 bg-white px-14 py-4 text-slate-900 shadow-xl"
            />
            {search && (
              <button
                type="button"
                onClick={() => setSearch('')}
                className="absolute right-4 top-1/2 grid h-8 w-8 -translate-y-1/2 place-items-center rounded-full bg-slate-100 text-slate-500"
                aria-label="Clear search"
              >
                <X size={16} />
              </button>
            )}
          </div>
        </div>
      </section>

      <section className="border-b border-slate-200 bg-white px-4 py-4 sm:px-6">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 md:flex-row md:items-center">
          <select
            value={division}
            onChange={(event) => {
              setDivision(event.target.value);
              setPage(1);
            }}
            className="rounded-lg border border-slate-200 px-4 py-3 text-sm font-semibold text-slate-700"
          >
            <option value="">All divisions</option>
            {divisions.map((item) => (
              <option key={item.id} value={item.id}>{item.name}</option>
            ))}
          </select>
          <select
            value={category}
            onChange={(event) => {
              setCategory(event.target.value);
              setPage(1);
            }}
            className="rounded-lg border border-slate-200 px-4 py-3 text-sm font-semibold text-slate-700"
          >
            <option value="">All product categories</option>
            {categories.map((item) => (
              <option key={item.id} value={item.id}>{item.name}</option>
            ))}
          </select>
          <div className="flex-1" />
          <span className="text-sm font-semibold text-slate-500">{meta.count} products</span>
          {hasFilters && (
            <button type="button" onClick={resetFilters} className="rounded-lg border border-slate-200 px-4 py-3 text-sm font-bold text-teal">
              Reset
            </button>
          )}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
        {error && <div className="mb-6 rounded-lg border border-red-200 bg-red-50 p-4 text-red-700">{error}</div>}
        {loading ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, index) => (
              <div key={index} className="h-72 animate-pulse rounded-lg bg-white" />
            ))}
          </div>
        ) : products.length ? (
          <>
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} onClick={() => navigate(`/products/${product.id}`)} />
              ))}
            </div>
            <div className="mt-10 flex items-center justify-center gap-3">
              <button
                type="button"
                disabled={!meta.has_previous}
                onClick={() => setPage((value) => Math.max(value - 1, 1))}
                className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-bold disabled:opacity-40"
              >
                Previous
              </button>
              <span className="text-sm font-semibold text-slate-500">Page {meta.page} of {meta.total_pages || 1}</span>
              <button
                type="button"
                disabled={!meta.has_next}
                onClick={() => setPage((value) => value + 1)}
                className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-bold disabled:opacity-40"
              >
                Next
              </button>
            </div>
          </>
        ) : (
          <div className="rounded-lg border border-slate-200 bg-white p-12 text-center">
            <h2 className="text-2xl font-bold text-slate-900">No products found</h2>
            <button type="button" onClick={resetFilters} className="mt-5 rounded-full bg-teal px-6 py-3 text-sm font-bold text-white">
              Reset filters
            </button>
          </div>
        )}
      </section>
    </div>
  );
}
