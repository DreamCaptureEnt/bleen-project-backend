import React, { useEffect, useState } from 'react';
import { ArrowRight, Building2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { api } from '../api';

function formatDate(value) {
  if (!value) return '';
  return new Intl.DateTimeFormat('en-IN', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value));
}

export default function Divisions() {
  const [divisions, setDivisions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    api.divisions({ page_size: 100 })
      .then((data) => {
        setDivisions(data.results);
        setError('');
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen bg-slate-50">
      <section className="bg-gradient-to-br from-slate-900 via-navy to-teal px-4 py-20 text-white sm:px-6">
        <div className="mx-auto max-w-6xl">
          <p className="text-sm font-bold uppercase tracking-[0.22em] text-white/65">Our Divisions</p>
          <h1 className="mt-5 max-w-3xl text-4xl font-black leading-tight sm:text-6xl">Dynamic business divisions</h1>
          <p className="mt-5 max-w-2xl text-base leading-7 text-white/75">
            Divisions are managed from the superuser dashboard and shown here directly from the Django backend.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
        {error && <div className="mb-6 rounded-lg border border-red-200 bg-red-50 p-4 text-red-700">{error}</div>}
        {loading ? (
          <div className="grid gap-6 md:grid-cols-2">
            {Array.from({ length: 4 }).map((_, index) => (
              <div key={index} className="h-56 animate-pulse rounded-lg bg-white" />
            ))}
          </div>
        ) : divisions.length ? (
          <div className="grid gap-6 md:grid-cols-2">
            {divisions.map((division, index) => (
              <article key={division.id} className="rounded-lg border border-slate-200 bg-white p-7 shadow-sm">
                <div className="flex items-start gap-5">
                  <div className="grid h-14 w-14 place-items-center rounded-lg bg-teal-50 text-teal">
                    <Building2 size={26} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-black text-slate-300">0{index + 1}</p>
                    <h2 className="mt-1 text-2xl font-black text-slate-900">{division.name}</h2>
                    <p className="mt-3 text-sm font-semibold text-slate-500">Created {formatDate(division.created_at)}</p>
                    <Link to={`/products?division=${division.id}`} className="mt-6 inline-flex items-center gap-2 text-sm font-bold text-teal">
                      Explore products <ArrowRight size={16} />
                    </Link>
                  </div>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <div className="rounded-lg border border-slate-200 bg-white p-12 text-center">
            <h2 className="text-2xl font-bold text-slate-900">No divisions yet</h2>
            <p className="mt-3 text-slate-500">Create divisions from the admin dashboard.</p>
          </div>
        )}
      </section>
    </div>
  );
}
